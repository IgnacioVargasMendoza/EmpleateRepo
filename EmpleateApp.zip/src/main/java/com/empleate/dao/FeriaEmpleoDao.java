
package com.empleate.dao;

import com.empleate.domain.FeriaEmpleo;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Ignac
 */
public interface FeriaEmpleoDao extends JpaRepository<FeriaEmpleo, Long>{
    
}
