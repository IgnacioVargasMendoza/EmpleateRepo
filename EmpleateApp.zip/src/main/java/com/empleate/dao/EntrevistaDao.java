
package com.empleate.dao;

import com.empleate.domain.Entrevista;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Ignac
 */
public interface EntrevistaDao extends JpaRepository<Entrevista, Long>{
    
}
