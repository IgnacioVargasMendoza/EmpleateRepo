package com.empleate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpleateApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpleateApplication.class, args);
	}

}
